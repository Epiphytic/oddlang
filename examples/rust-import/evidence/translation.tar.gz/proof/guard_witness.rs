/// Test generated for harness `guard_priority_counterexample`
///
/// Check for `assertion`: ""exact named result differs""

#[test]
fn kani_concrete_playback_guard_priority_counterexample_18360966371845015864() {
    let concrete_vals: Vec<Vec<u8>> = vec![
        // -1
        vec![255, 255, 255, 255, 255, 255, 255, 255],
    ];
    kani::concrete_playback_run(concrete_vals, guard_priority_counterexample);
}
